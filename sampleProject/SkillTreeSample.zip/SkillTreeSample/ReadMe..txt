/*************************************************************
First of all
*************************************************************/

No img folder and audio folder are attached to this project.

Please copy img folder and audio folder from your project before starting.

----------------
by futokoro
july 2017
