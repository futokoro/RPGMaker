/*************************************************************
First of all
*************************************************************/

No img folder and audio folder are attached to this project.

Please copy img folder and audio folder from your project before starting.



MV_Core_Script v1.5.1

----------------
by futokoro
july 2017
